@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <div class="wrapper wrapper-content animated fadeInRight">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center m-t-lg">
                            <h1>
                                Welcome in <b>Daily Rashan</b>  Dashboard.
                            </h1>
                            <small>
                                Manage All Clients And Branch.
                            </small>
                        </div>
                    </div>
                </div>
            </div>
@endsection