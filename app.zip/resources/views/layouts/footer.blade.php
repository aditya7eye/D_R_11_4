<div class="footer">
    <div class="pull-right">
        Example text
    </div>
    <div>
        <strong>Copyright</strong> Example Company &copy; 2014-2017
    </div>
</div>
