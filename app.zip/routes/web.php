<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

////////----Dashboard

Route::get('/', 'LoginController@login');
Route::POST('check_user', 'LoginController@check_user');
Route::get('logout', 'LoginController@logout');

Route::group(['middleware' => 'usersession'], function () {
    Route::get('master_dashboard', 'MasterController@master_dashboard')->name("master_dashboard");
});
